/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author MDM
 */
public class GenericCollectionTest {

    public static void main(String[] args) {
        List<String> myList = new ArrayList<>();
        myList.add("Satu");
        myList.add("Tiga");
        myList.add("Lima");
        for(String element: myList) {
            System.out.println(element);
        }
        
        Map<Integer, String> myMap = new HashMap<>();
        myMap.put(1, "Satu");
        myMap.put(2, "Dua");
        System.out.println(myMap);

        Set<Integer> mySet = new HashSet();
        mySet.add(1);
        mySet.add(3);
        mySet.add(7);
        System.out.println(mySet);
        
        Set<String> mySet2 = new TreeSet();
        mySet2.add("Bob");
        mySet2.add("Jack");
        mySet2.add("Alice");
        System.out.println(mySet2);

        
    }
}
