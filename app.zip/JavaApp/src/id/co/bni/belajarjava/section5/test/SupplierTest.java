/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

/**
 *
 * @author MDM
 */
public class SupplierTest {
    /*
    untuk mengembalikan nilai
     */
}
