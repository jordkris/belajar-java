/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 *
 * @author MDM
 */
public class ConsumerTest {

    public static void main(String[] args) {
        Consumer<String> printName = (name) -> System.out.println(name);
        Consumer<Integer> squareArea = (s) -> {
            int area = s * s;
            System.out.println(area);
        };
        printName.accept("Bob");
        squareArea.accept(20);
        BiConsumer<Integer, Integer> boxArea = (w, h) -> {
            int area = w * h;
            System.out.println(area);
        };
        boxArea.accept(4, 19);
    }
}
