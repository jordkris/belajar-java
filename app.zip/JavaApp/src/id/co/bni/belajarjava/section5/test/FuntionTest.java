/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import java.util.function.Function;

/**
 *
 * @author MDM
 */
public class FuntionTest {
    public static void main(String[] args) {
        Function<String, String> uppercaseText = (text) -> {
            return text.toUpperCase();
        };
        Function<String, String> reverseText = (text) -> {
            return new StringBuilder(text).reverse().toString();
        };
        System.out.println(uppercaseText.apply("hello apa kabar?"));
        System.out.println(reverseText.apply("hello apa kabar?"));
        System.out.println(uppercaseText.andThen(reverseText).apply("hello apa kabar?"));
    }
}
