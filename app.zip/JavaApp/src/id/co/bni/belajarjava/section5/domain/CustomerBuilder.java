/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.domain;

import java.time.LocalDate;

public class CustomerBuilder {

    private int customerId;
    private String name;
    private String address;
    private LocalDate customerDob;

    public CustomerBuilder() {
    }

    public CustomerBuilder(int customerId, String name, String address, LocalDate customerDob) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.customerDob = customerDob;
    }

    public CustomerBuilder setCustomerId(int customerId) {
        this.customerId = customerId;
        return this;
    }

    public CustomerBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public CustomerBuilder setAddress(String address) {
        this.address = address;
        return this;
    }

    public CustomerBuilder setCustomerDob(LocalDate customerDob) {
        this.customerDob = customerDob;
        return this;
    }

    public Customer createCustomer() {
        return new Customer(customerId, name, address, customerDob);
    }

}
