/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import id.co.bni.belajarjava.section5.domain.Customer;
import id.co.bni.belajarjava.section5.domain.CustomerBuilder;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 *
 * @author MDM
 */
public class StreamTest {

    public static void main(String[] args) {
        Stream<String> streamString = Stream.of("John", "Jane", "Ann", "Bob");
        IntStream streamInt = IntStream.of(0, 1, 3, 6, 7, 9);
        Stream<Customer> teamCust = Stream.of(
                new CustomerBuilder()
                        .setCustomerId(123)
                        .setName("Ann")
                        .setAddress("London")
                        .setCustomerDob(LocalDate.of(1998, Month.APRIL, 2)).createCustomer(),
                new CustomerBuilder()
                        .setCustomerId(125)
                        .setName("Jack")
                        .setAddress("Singapore")
                        .setCustomerDob(LocalDate.of(1995, Month.JANUARY, 2)).createCustomer(),
                new Customer(
                        127,
                        "Bob",
                        "Kuala Lumpur",
                        LocalDate.of(2000, Month.MARCH, 25)
                )
        );
        streamString.forEach(e -> {
            if (e.contains("a")) {
                System.out.println(e);
            }
        });

        streamInt.forEach(e -> {
            if (e % 2 == 0) {
                System.out.println(e);
            }
        });
        System.out.println("");
        int[] values = {3, 4, 6, 2, 0, 6, 8, 4, 3, 5, 36, 6, 347, 357, 357, 3, 3, 5, 7, 7, 7, 2};
        int max = Arrays.stream(values).max().getAsInt();
        int min = Arrays.stream(values).min().getAsInt();
        double avg = Arrays.stream(values).average().getAsDouble();
        Arrays.stream(values).sorted().distinct().forEach(e -> System.out.println(e));
        System.out.println("Max: " + max);
        System.out.println("Min: " + min);
        System.out.println("Average: " + avg);
        Arrays.stream(values).filter(i -> i % 2 == 0).distinct().sorted().forEach(System.out::println);

        long start = System.nanoTime();
        for (int i = 0; i < 1000; i++) {
            System.out.print(i);
        }
        long finish = System.nanoTime();
        System.out.println("");
        System.out.println("For: " + (finish - start) / 1000000 + " ms");

        start = System.nanoTime();
        IntStream.range(0, 1000).forEach(System.out::print);
        finish = System.nanoTime();
        System.out.println("");
        System.out.println("Stream: " + (finish - start) / 1000000 + " ms");

    }
}
