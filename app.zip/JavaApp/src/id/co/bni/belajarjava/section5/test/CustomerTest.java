/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import id.co.bni.belajarjava.section5.domain.Customer;
import id.co.bni.belajarjava.section5.domain.CustomerBuilder;
import id.co.bni.belajarjava.section5.domain.CustomerNameComparator;
import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author MDM
 */
public class CustomerTest {

    public static void main(String[] args) {
        Set<Customer> myCustomers = new HashSet<>();
        myCustomers.add(new CustomerBuilder().setCustomerId(123).setName("Andi").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
        myCustomers.add(new CustomerBuilder().setCustomerId(102).setName("Budi").setAddress("Bandung").setCustomerDob(LocalDate.of(1999, Month.MARCH, 5)).createCustomer());
        myCustomers.add(new CustomerBuilder().setCustomerId(99).setName("Cahyo").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
        for (Customer c : myCustomers) {
            System.out.println(c);
        }

        Set<Customer> myCustomers2 = new TreeSet<>();
        myCustomers2.add(new CustomerBuilder().setCustomerId(99).setName("Andi").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
        myCustomers2.add(new CustomerBuilder().setCustomerId(102).setName("Budi").setAddress("Bandung").setCustomerDob(LocalDate.of(1999, Month.MARCH, 5)).createCustomer());
        myCustomers2.add(new CustomerBuilder().setCustomerId(78).setName("Cahyo").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
//        for(Customer c: myCustomers2) {
//            System.out.println(c);
//        }
        myCustomers2.forEach(element -> System.out.println(element));

        Set<Customer> myCustomers3 = new TreeSet<>(new CustomerNameComparator());
        myCustomers3.add(new CustomerBuilder().setCustomerId(99).setName("Budi").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
        myCustomers3.add(new CustomerBuilder().setCustomerId(102).setName("Andi").setAddress("Bandung").setCustomerDob(LocalDate.of(1999, Month.MARCH, 5)).createCustomer());
        myCustomers3.add(new CustomerBuilder().setCustomerId(78).setName("Cahyo").setAddress("Jakarta").setCustomerDob(LocalDate.of(1999, Month.MARCH, 4)).createCustomer());
        myCustomers3.forEach(element -> System.out.println(element));

        System.out.println("");
        CustomerBuilder cb = new CustomerBuilder();
        cb.setCustomerId(123);
        cb.setName("Doni");
        cb.setAddress("Bogor");
        cb.setCustomerDob(LocalDate.of(1998, Month.MARCH, 6));
        Customer c1 = cb.createCustomer();
        System.out.println(c1);

        Customer c2 = cb.setCustomerId(123)
                .setName("Doni")
                .setAddress("Bogor")
                .setCustomerDob(LocalDate.of(1998, Month.MARCH, 6))
                .createCustomer();
        System.out.println(c2);
        System.out.println();
    }
}
