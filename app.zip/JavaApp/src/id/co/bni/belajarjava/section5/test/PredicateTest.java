/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.test;

import java.util.function.Predicate;

/**
 *
 * @author MDM
 */
public class PredicateTest {

    public static void main(String[] args) {
        Predicate<Integer> isEven = (num) -> (num % 2) == 0;
        if (isEven.test(20)) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
        boolean test = isEven
                .and(i -> i > 100 && i < 1000)
                .or(i-> i==800 || i==900)
                .test(802);
        System.out.println(test);
    }
}
