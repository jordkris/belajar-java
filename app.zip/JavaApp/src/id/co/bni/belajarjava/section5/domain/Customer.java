/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section5.domain;

import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author MDM
 */
public class Customer implements Comparable<Customer> {

    int customerId;
    String name;
    String address;
    LocalDate customerDob;

    public Customer(int customerId, String name, String address, LocalDate customerDob) {
        this.customerId = customerId;
        this.name = name;
        this.address = address;
        this.customerDob = customerDob;
    }

    @Override
    public String toString() {
        return "Customer{" + "customerId=" + customerId + ", name=" + name + ", address=" + address + ", customerDob=" + customerDob + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (this.customerId != other.customerId) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.address, other.address)) {
            return false;
        }
        return Objects.equals(this.customerDob, other.customerDob);
    }

    @Override
    public int compareTo(Customer o) {
        int delta = customerId - o.customerId;
        if (delta > 0) {
            return 1;
        } else if (delta == 0) {
            return name.compareTo(o.name);
        } else {
            return -1;
        }
    }
}

