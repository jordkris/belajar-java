/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import static java.lang.System.out;

/**
 *
 * @author MDM
 */
class Person {

    /*
    static
    - class : hanya bisa dilakukan pada inner class
    - method : hanya akan mengimplementasikan static variable
    - variable : digunakan bersama
     */
    String name;
    static String address; // dipakai bersama, jika diupdate maka akan berubah di instance lain
    // static intitializers

    static {
        out.println("Static initializers ...");
        address = "UNKNOWN";
    }

    public static void methodX() {
        String n = new Person().name; // 
        String addr = address;
    }

    public void displayPersonInfo() {
        out.println("Name: " + name + ", address: " + address);
    }
}

class Outer {

    int x = 1000;
    static int y = 2000;

    class Inner1 {

        int x = 10;
        static int y = 20;
    }

    static class Inner2 {

        int x = 100;
        static int y = 200;
    }
}

public class StaticTest {

    public static void main(String[] args) {
        new Person().displayPersonInfo();
        Person p1 = new Person();
        Person p2 = new Person();
        p1.name = "Steven";
        p1.address = "Manchester";
        p2.name = "John";
        p2.address = "Jakarta";
        p1.displayPersonInfo();
        p2.displayPersonInfo();
        new Person().displayPersonInfo();

        Outer o1 = new Outer();
        System.out.println(o1.x);
        System.out.println(Outer.y);
        Outer.Inner1 oi1 = o1.new Inner1();
        System.out.println(oi1.x);
        System.out.println(Outer.Inner1.y);

        Outer.Inner2 oi2 = new Outer.Inner2();
        System.out.println(oi2.x);
        System.out.println(Outer.Inner2.y);
    }
}
