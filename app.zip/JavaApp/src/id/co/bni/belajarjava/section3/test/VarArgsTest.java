/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

/**
 *
 * @author MDM
 */
public class VarArgsTest {
    public int add(int ... a) {
        int total = 0;
        
        for(int element: a) {
            total += element;
        }
        return total;
    }
    
    public static void main(String[] args) {
        VarArgsTest x = new VarArgsTest();
        System.out.println(x.add(1,2,3,4,5,6));
    }
}
