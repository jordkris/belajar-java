/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import id.co.bni.belajarjava.section2.domain.Employee;
import id.co.bni.belajarjava.section3.domain.Manager;

/**
 *
 * @author MDM
 */
public class PolimorphismTest {
    public static void main(String[] args) {
        Employee e1 = new Manager(100,"Budi","1235", 24000, "Executive");
        e1.displayEmployeeInfo(); // execute child
        System.out.println(e1.hashCode());
    }
    
}
