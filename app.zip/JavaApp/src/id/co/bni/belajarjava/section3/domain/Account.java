/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.domain;

import java.util.UUID;

/**
 *
 * @author MDM
 */
public abstract class Account {

    private final String accountId;
    protected double balance;

    public Account(double initBalance) {
        balance = initBalance;
        accountId = generateUniqueAccountId();
    }

    public String getAccountId() {
        return accountId;
    }

    private String generateUniqueAccountId() {
        return UUID.randomUUID().toString();
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void displayAccountInfo() {
        System.out.println("Final balance for " + getAccountId() + " is: " + getBalance());
    }

    public void deposit(double amount) {
        setBalance(getBalance() + amount);
    }

    public void withdraw(double amount) {
        if (amount < balance) {
            setBalance(getBalance() - amount);
        } else {
            System.out.println("Insufficiant blance!");
        }
    }
    
    public abstract void printAccountInfo();
}
