/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import id.co.bni.belajarjava.section3.domain.MyDate;
import id.co.bni.belajarjava.section4.domain.Hari;

/**
 *
 * @author MDM
 */
public class MyDateTest {
    public static void main(String[] args) {
        MyDate today = new MyDate(4,7,2023,Hari.RABU);
        System.out.println(today);
        MyDate date2 = new MyDate(4,7,2023,Hari.KAMIS);
        System.out.println(date2);
        System.out.println(date2.equals(today)); // bernilai true karena 
    }
}
