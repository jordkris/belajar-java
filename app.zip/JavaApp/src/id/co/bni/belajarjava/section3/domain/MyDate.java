/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.domain;

import id.co.bni.belajarjava.section4.domain.Hari;
import lombok.*;

/**
 *
 * @author MDM
 */
@Data
@AllArgsConstructor
public class MyDate {

    private int date;
    private int month;
    private int year;
    private Hari day;

    @Override
    public String toString() {
        return "MyDate{" + "date=" + date + ", month=" + month + ", year=" + year + ", day=" + day + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof MyDate) {
            MyDate md = (MyDate) obj;
            if (md.day == day && md.month == month && md.year == year) {
                result = true;
            }
        }
        return result;
    }

}
