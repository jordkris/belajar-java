/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import id.co.bni.belajarjava.section3.domain.SingletonClass;

/**
 *
 * @author MDM
 */
public class SingletonTest {

    public static void main(String[] args) {
        SingletonClass xxx = SingletonClass.getInstance();
        SingletonClass yyy = SingletonClass.getInstance();

        System.out.println(System.identityHashCode(xxx));
        System.out.println(System.identityHashCode(yyy));
    }
}
