/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import id.co.bni.belajarjava.section3.domain.Admin;

/**
 *
 * @author MDM
 */
public class InheritanceTest {
    public static void main(String[] args) {
        Admin a1 = new Admin(1234, "John", "3256-7890", 2000);
        a1.displayEmployeeInfo();
    }
}
