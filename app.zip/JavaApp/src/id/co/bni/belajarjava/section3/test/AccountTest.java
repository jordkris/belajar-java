/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.test;

import id.co.bni.belajarjava.section3.domain.Account;

/**
 *
 * @author MDM
 */
public class AccountTest {
    public static void main(String[] args) {
//        Account myAccount = new Account(1000);
//        myAccount.setBalance(1000);
//        myAccount.withdraw(500);
//        myAccount.displayAccountInfo();
//        myAccount.deposit(250);
        
    }
}
