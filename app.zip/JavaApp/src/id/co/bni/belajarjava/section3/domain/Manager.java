/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section3.domain;

import id.co.bni.belajarjava.section2.domain.Employee;

/**
 *
 * @author MDM
 */
public class Manager extends Employee {

    private String departmentName;

    public Manager(int empId, String name, String ssn, double salary, String departmentName) {
        super(empId, name, ssn, salary);
        this.departmentName = departmentName;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    @Override
    public void displayEmployeeInfo() {
        super.displayEmployeeInfo();
        System.out.println("Department Name: " + departmentName);
    }
}
