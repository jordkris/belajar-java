/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2;

/**
 *
 * @author MDM
 */
public class ArrayTest {
    
    public static void printArray(int[] array) {
        System.out.print("[ ");
        for(int integer: array) {
            System.out.print(integer+" ");
        }
        System.out.println("]");
    }
    public static void main(String[] args) {
        int[] myArray;
        myArray = new int[4];
        myArray[0] = 10;
        myArray[1] = 20;
        myArray[2] = 30;
        myArray[3] = 40;
        
        int myArray2[] = {100, 200, 300, 400};
        
        for (int i=0; i< myArray.length; i++) {
            System.out.println(myArray[i]);
        }
        
//        myArray = new int[8];
        
        for(int element: myArray2) {
            System.out.println(element);
        }
        
        System.out.println("myArray: "+System.identityHashCode(myArray));
        printArray(myArray);
        System.out.println("myArray2: "+System.identityHashCode(myArray2));
        printArray(myArray2);
    }
}
