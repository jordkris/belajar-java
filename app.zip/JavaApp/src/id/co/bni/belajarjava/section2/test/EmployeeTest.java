/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2.test;

import id.co.bni.belajarjava.section2.domain.Employee;

/**
 *
 * @author MDM
 */
public class EmployeeTest {
     public static void main(String[] args) {
        Employee e1 = new Employee();
        e1.displayEmployeeInfo();
        Employee e2 = new Employee(1234, "John", "3256-7890", 2000);
        e2.displayEmployeeInfo();
//      Employee Id: 1234
//      Employee Name: John
//      Employee Ssn: 3256-7890
//      Salary: 2000.0

        Employee e3 = e2;
        e3.displayEmployeeInfo();
//      Employee Id: 1234
//      Employee Name: John
//      Employee Ssn: 3256-7890
//      Salary: 2000.0
        e2.salary = 1000;
        e3.displayEmployeeInfo();
//      Employee Id: 1234
//      Employee Name: John
//      Employee Ssn: 3256-7890
//      Salary: 1000.0
        e2 = new Employee();
        e3.displayEmployeeInfo();
//      Employee Id: 1234
//      Employee Name: John
//      Employee Ssn: 3256-7890
//      Salary: 1000.0

    }
}
