/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2.domain;

import java.time.LocalDate;
import java.time.Month;

/**
 *
 * @author MDM
 */
public class CreditCard {

    public final int VISA = 5001;
    public String accountName;
    public String cardNumber;
    public LocalDate expDate;

    public void displayCreditCardInfo() {
        System.out.println("Account name: " + accountName);
        System.out.println("Card number: " + cardNumber);
        System.out.println("Exp date: " + expDate);
    }

    public static void main(String[] args) {
        CreditCard cc = new CreditCard();
        cc.accountName = "Ronald";
        cc.cardNumber = "1234 1234 1234";
        cc.expDate = LocalDate.of(2025, Month.MARCH, 22);
        cc.displayCreditCardInfo();     
    }
}
