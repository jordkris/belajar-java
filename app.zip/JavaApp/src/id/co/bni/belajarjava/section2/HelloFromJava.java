/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package id.co.bni.belajarjava.section2;

import java.util.Scanner;

/**
 * Ini adalah contoh simple java class
 * @author MDM
 */
public class HelloFromJava {

    /**
     * Ini adalah main class
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hello World!");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.next();
        System.out.printf("Welcome %s, enjoy your learn%n",name);
    }
    
}
