/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2;

/**
 *
 * @author MDM
 */
public class Latihan {

    public static void main(String[] args) {
        int x1 = 100;
        int x2 = 1_000_000;
        long cardNum = 1234_1234_1234_1234L;
        int x3 = 0B1010_1111_0101;
        float f1 = 5000.0F;
        double d1 = 5000.0;
        System.out.println("x1: " + x1);
        System.out.println("x2: " + x2);
        System.out.println("cardNum: " + cardNum);
        System.out.println("x3: " + x3);
        System.out.println("f1: " + f1);
        System.out.println("d1: " + d1);

        if (x1 == 1000) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }
        String output = (x1 == 1000) ? "yes" : "no";
        System.out.println(output);
        String greeting = "";
        int time = 700;
        if (time > 0 && time < 500) {
            greeting = "Early Morning";
        } else if (time >= 500 && time < 1100) {
            greeting = "Morning";
        } else if (time >= 1100 && time < 1500) {
            greeting = "Afternoon";
        }
        System.out.println("Good " + greeting);
        String value = "one";
        if(value.equals("one")) {
            System.out.println("Satu");
        } else if (value.equals("two")) {
            System.out.println("Dua");
        }
        
        switch(value) {
            case "one":
                System.out.println("Satu");
                break;
            case "two":
                System.out.println("Dua");
                break;
            default:
                System.out.println("Unknown");
        }
    }
}
