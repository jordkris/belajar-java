/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2.domain;

import id.co.bni.belajarjava.section3.domain.Admin;
import id.co.bni.belajarjava.section3.domain.Engineer;
import id.co.bni.belajarjava.section3.domain.Manager;

/**
 *
 * @author MDM
 */
public class Employee {

    public int empId;
    public String empName;
    public String empSsn;
    public double salary;

    public Employee(int empId, String empName, String empSsn, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.empSsn = empSsn;
        this.salary = salary;
    }

    public Employee() {
    }

    /*
    final
    - class : tidak dapat diextends
    - method : tidak dapat dioverride
    - variable : tidak dapat diubah valuenya
    */
    public void displayEmployeeInfo() { // public final void displayEmployeeInfo()
        String title = "";
        if (this instanceof Admin) {
            title = "Admin";
        } else if (this instanceof Engineer) {
            title = "Engineer";
        } else if (this instanceof Manager) {
            title = "Admin";
        } else {
            title = "Employee";
        }
        System.out.println("====================");
        System.out.println("Employee Id: " + empId);
        System.out.println("Employee Name: " + empName);
        System.out.println("Title: " + title);
        System.out.println("Employee Ssn: " + empSsn);
        System.out.println("Salary: " + salary);
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpSsn() {
        return empSsn;
    }

    public void setEmpSsn(String empSsn) {
        this.empSsn = empSsn;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

}
