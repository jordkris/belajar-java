/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2;

/**
 *
 * @author MDM
 */
public class StringTest {

    public static void main(String[] args) {
        /*
            String => immutable of chars (akan membuat lokasi yang berbeda2 sehingga makan memori)
            StringBuilder => mutable of chars (akan menyimpan string di lokasi yang sama)
            StringBuffer => mutable of chars (samadengan StringBuilder tapi thread safe / string akan aman atau konsiten jika diakses lebih dari 1 thread
         */
        String s = "Hello,";
        System.out.println("Location: " + System.identityHashCode(s));
        s += " apa";
        System.out.println("Location: " + System.identityHashCode(s));
        s += " kabar?";
        System.out.println("Location: " + System.identityHashCode(s));

        StringBuilder sb = new StringBuilder("Hello,");
        System.out.println("Location: " + System.identityHashCode(sb));
        sb.append(" apa");
        System.out.println("Location: " + System.identityHashCode(sb));
        sb.append("kabar?");
        System.out.println("Location: " + System.identityHashCode(sb));

    }

}
