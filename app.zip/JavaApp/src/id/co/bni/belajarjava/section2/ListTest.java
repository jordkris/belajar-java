/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MDM
 */
public class ListTest {

    public static void main(String[] args) {
        List myList = new ArrayList();
        myList.add(10);
        myList.add("a");
        System.out.println(myList.toString());
    }
}
