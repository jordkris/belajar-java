/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section4.domain;

/**
 *
 * @author MDM
 */
public class Fish extends Animal implements Pet {

    private String name;

    public Fish(String name) {
        super(0);
        this.name = name;
    }

    @Override
    public void walk() {
        System.out.println("Fist doesn't walk, it's swim");
    }

    @Override
    public void eat() {
        System.out.println("Fish eats plankton");
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void play() {

    }
}
