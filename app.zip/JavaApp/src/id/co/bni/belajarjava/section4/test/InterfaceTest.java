/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package id.co.bni.belajarjava.section4.test;

/**
 *
 * @author MDM
 */
/*
    Default interface:
    - class : public interface
    - method : public abstract
    - variable : public static final
 */
interface A {

    void methodA();

    default void methodDefaultA() {
        System.out.println("methodDefaultA");
    }

    static void methodDefaultB() {
        System.out.println("methodDefaultB");
    }
}

interface B {

}

interface C extends A, B {

}

class X implements C {

    @Override
    public void methodA() {
        System.out.println("class X");
    }

}

@FunctionalInterface
interface StringAnalyzer {

    public boolean analyze(String source, String search);
}

class AnalyzerTool implements StringAnalyzer {

    @Override
    public boolean analyze(String source, String search) {
        return source.contains(search);
    }

}

@FunctionalInterface
interface SimpleCalculator {

    int operation(int var1, int var2);
}

public class InterfaceTest {

    public static void main(String[] args) {
        X x = new X();
        x.methodA();

        AnalyzerTool at1 = new AnalyzerTool();
        System.out.println(at1.analyze("Hello, apa kabar?", "apa"));
        System.out.println(at1.analyze("Hello, apa kabar?", "apa?"));

        // Anonymus Class
        StringAnalyzer sa = new StringAnalyzer() {
            @Override
            public boolean analyze(String source, String search) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };

        // lambda expression
        StringAnalyzer sa2 = (String source, String search) -> {
            return source.contains(search);
        };

        SimpleCalculator add = (var1, var2) -> var1 + var2;
        System.out.println(add.operation(1, 2));

        SimpleCalculator mod = (var1, var2) -> var1 % var2;
        System.out.println(mod.operation(7, 3));

    }
}
