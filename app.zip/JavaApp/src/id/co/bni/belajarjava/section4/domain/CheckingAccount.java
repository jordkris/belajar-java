/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section4.domain;

import id.co.bni.belajarjava.section3.domain.Account;

/**
 *
 * @author MDM
 */
public class CheckingAccount extends Account {

    private double overdraftLimit;

    public CheckingAccount(double initBalance, double overdraftLimit) {
        super(initBalance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void withdraw(double amount) {
        if (amount < getBalance()) {
            super.withdraw(amount);
        } else {
            if (overdraftLimit > 0.0) {
                double overdraftNeeded = amount - balance;
                if (overdraftNeeded < overdraftLimit) {
                    balance = 0;
                    overdraftLimit -= overdraftNeeded;
                } else {
                    System.out.println("Insufficient overdraft limit");
                }
            } else {
                System.out.println("This account doesn't have overdraft limit");
            }
        }
    }

    @Override
    public void deposit(double amount) {
        super.deposit(amount);
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }

    @Override
    public void printAccountInfo() {
        System.out.println("Account balance: " + getBalance());
        System.out.println("Overdraft limit: " + getOverdraftLimit());
    }

}
