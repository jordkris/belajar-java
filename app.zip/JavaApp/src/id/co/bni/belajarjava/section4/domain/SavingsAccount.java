package id.co.bni.belajarjava.section4.domain;

import id.co.bni.belajarjava.section3.domain.Account;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author MDM
 */
public class SavingsAccount extends Account {

    private double interestRate;

    public SavingsAccount(double initBalance, double interestRate) {
        super(initBalance);
        this.interestRate = interestRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    @Override
    public void printAccountInfo() {
        System.out.println("Saving Account balance: " + getBalance());
        System.out.println("Interest Rate: " + getInterestRate());
    }

}
