/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package id.co.bni.belajarjava.section4.test;

import id.co.bni.belajarjava.section3.domain.Account;
import id.co.bni.belajarjava.section4.domain.CheckingAccount;
import id.co.bni.belajarjava.section4.domain.SavingsAccount;

/**
 *
 * @author MDM
 */
public class AccountTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Account a1 = new CheckingAccount(100, 56);
        a1.withdraw(50);
        a1.printAccountInfo();
        a1.withdraw(57);
        a1.printAccountInfo();
        Account a2 = new SavingsAccount(100, 56);
        a2.withdraw(50);
        a2.printAccountInfo();
        a2.withdraw(57);
        a2.printAccountInfo();

        Account a3 = new Account(1000) {
            @Override
            public void printAccountInfo() {
                System.out.println("balance: " + this.getBalance());
            }
        };
        a3.printAccountInfo();
    }

}
