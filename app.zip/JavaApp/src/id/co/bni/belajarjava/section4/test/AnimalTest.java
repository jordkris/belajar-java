/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section4.test;

import id.co.bni.belajarjava.section4.domain.Animal;
import id.co.bni.belajarjava.section4.domain.Cat;
import id.co.bni.belajarjava.section4.domain.Pet;
import id.co.bni.belajarjava.section4.domain.Spider;

/**
 *
 * @author MDM
 */
public class AnimalTest {

    public static void main(String[] args) {
        Animal a1 = new Spider();
        a1.eat();
        a1.walk();
        Animal a2 = new Cat("Tom");
        a2.eat();
        a2.walk();
        Pet p1 = new Cat("Tom");
         p1.play();
        Cat c1 = (Cat) p1;
        c1.eat();
       
    }
}
