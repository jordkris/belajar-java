/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package id.co.bni.belajarjava.section4.domain;

/**
 *
 * @author MDM
 */
public enum Hari {
    SENIN(1,"Monday"),
    SELASA(2,"Tuesday"),
    RABU(3,"Wednesday"),
    KAMIS(4,"Thrusday"),
    JUMAT(5, "Friday"),
    SABTU(6, "Saturday"),
    MINGGU(7,"Sunday");
    private int value;
    private String name;

    private Hari(int value, String name) {
        this.value = value;
        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
