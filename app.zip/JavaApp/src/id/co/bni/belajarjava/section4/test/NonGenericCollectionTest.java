/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package id.co.bni.belajarjava.section4.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author MDM
 */
public class NonGenericCollectionTest {
    public static void main(String[] args) {
        List myList = new ArrayList();
        myList.add("Satu");
        myList.add("Dua");
        myList.add("Satu");
        System.out.println(myList);
        
        Set mySet = new HashSet();
        mySet.add("Satu");
        mySet.add("Dua");
        System.out.println(mySet.add("Satu"));
        System.out.println(mySet);
    }
}
